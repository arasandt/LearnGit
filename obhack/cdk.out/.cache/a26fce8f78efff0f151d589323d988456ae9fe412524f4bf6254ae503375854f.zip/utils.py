import boto3

cw_client = boto3.client("cloudwatch")


def send_annotation_metric(app_name, annotation_value, count):
    response = cw_client.put_metric_data(
        Namespace="Custom/XRayAnnotations",  # Custom namespace
        MetricData=[
            {
                "MetricName": f"{app_name}_UserCount",  # Custom metric name
                "Dimensions": [
                    {"Name": "Annotation", "Value": annotation_value}  # e.g., "premium"
                ],
                "Value": count,  # Number of traces with the annotation
                "Unit": "Count",
            }
        ],
    )
