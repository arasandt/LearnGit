python3 -m venv nexusappenv
source nexusappenv/bin/activate
pip install wheel gunicorn flask aws-xray-sdk boto3
gunicorn --bind 0.0.0.0:5000 wsgi:app --daemon
deactivate

/bin/cp -f nexusapp.conf /etc/nginx/conf.d/nexusapp.conf


