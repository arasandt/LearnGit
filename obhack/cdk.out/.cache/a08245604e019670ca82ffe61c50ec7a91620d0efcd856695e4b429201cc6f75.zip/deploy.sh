python3 -m venv nexusappenv
source nexusappenv/bin/activate
pip install wheel gunicorn flask
gunicorn --bind 0.0.0.0:5000 wsgi:app --daemon
deactivate

/bin/cp -f service.conf /etc/nginx/conf.d/nexusapp.conf

systemctl enable nexusapp
systemctl start nexusapp
systemctl status nexusapp --no-pager

