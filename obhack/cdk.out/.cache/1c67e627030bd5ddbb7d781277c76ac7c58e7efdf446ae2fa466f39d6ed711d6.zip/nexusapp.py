from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.ext.flask.middleware import XRayMiddleware
from flask import Flask, render_template, request
from pathlib import Path

app_name = Path(__file__).stem
app = Flask(__name__)
xray_recorder.configure(service=app_name)
XRayMiddleware(app, xray_recorder)


@app.route("/")
def main():
    return render_template("home.html")


@app.route("/login")
def login():
    segment = xray_recorder.current_segment()

    # Get username and password from request
    username = request.args.get("username")
    password = request.args.get("password")

    # Add annotations (used for filtering)
    segment.put_annotation("request_type", "API")
    segment.put_annotation("username", username)

    # Add metadata (used for debugging)
    segment.put_metadata("processing_time", 150, "performance")

    return f"<h1 style='color:blue'>Logged in as {username} </h1>"


if __name__ == "__main__":
    app.run(host="0.0.0.0")
