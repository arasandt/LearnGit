from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.ext.flask.middleware import XRayMiddleware
from flask import Flask
from pathlib import Path

app_name = Path(__file__).stem
app = Flask(__name__)
xray_recorder.configure(service=app_name)
XRayMiddleware(app, xray_recorder)


@app.route("/")
def hello():
    return "<h1 style='color:blue'>Hello There!</h1>"


if __name__ == "__main__":
    app.run(host="0.0.0.0")
