python3 -m venv nexusappenv
source nexusappenv/bin/activate
pip install wheel gunicorn flask
deactivate

/bin/cp -f service.conf /etc/systemd/system/nexusapp.service

systemctl enable nexusapp
systemctl start nexusapp
systemctl status nexusapp --no-pager